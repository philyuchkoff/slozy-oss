# SLOzy Release v1.3.0

This archive contains everything needed to deploy SLOzy on CentOS/RHEL systems.

## Quick Installation

```bash
# Extract the archive
unzip slozy-v1.3.0.zip
cd release-v1.3.0

# Run the installation script (requires sudo)
sudo ./scripts/install-centos.sh
```

## Manual Installation

If you prefer manual installation:

1. **Copy files to target system**:
   ```bash
   # Copy the appropriate binary for your architecture
   cp slozy-server-linux-amd64 /opt/slozy/bin/slozy-server  # for Intel/AMD
   # or
   cp slozy-server-linux-arm64 /opt/slozy/bin/slozy-server  # for ARM
   ```

2. **Create service user**:
   ```bash
   sudo groupadd -r slozy
   sudo useradd -r -s /bin/false -g slozy -d /opt/slozy slozy
   ```

3. **Install files**:
   ```bash
   sudo mkdir -p /opt/slozy/{bin,data,templates,static,logs,config}
   sudo cp slozy-server-linux-* /opt/slozy/bin/slozy-server
   sudo cp -r static/* /opt/slozy/static/
   sudo cp -r templates/* /opt/slozy/templates/
   sudo cp config/.env.example /opt/slozy/.env
   sudo cp config/slozy.service /etc/systemd/system/
   ```

4. **Set permissions**:
   ```bash
   sudo chown -R slozy:slozy /opt/slozy
   sudo chmod +x /opt/slozy/bin/slozy-server
   ```

5. **Configure service**:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable slozy
   sudo systemctl start slozy
   ```

## Configuration

Edit the configuration file at `/opt/slozy/.env` to customize:

- Server port (default: 8080)
- Data directories
- Notification settings (Telegram, SMTP, etc.)

## Service Management

```bash
# Start service
sudo systemctl start slozy

# Stop service
sudo systemctl stop slozy

# Restart service
sudo systemctl restart slozy

# Check status
sudo systemctl status slozy

# View logs
sudo journalctl -u slozy -f
```

## Troubleshooting

1. **Service won't start**:
   ```bash
   sudo journalctl -u slozy -n 50
   ```

2. **Port already in use**:
   Edit `/opt/slozy/.env` and change the PORT value, then restart the service.

3. **Permission issues**:
   ```bash
   sudo chown -R slozy:slozy /opt/slozy
   sudo chmod -R 755 /opt/slozy
   ```

## Support

For issues and questions:
- GitHub: https://github.com/philyuchkoff/slozy
- Documentation: https://slozy.ru
