#!/bin/bash
#
# SLOzy CentOS Installation Script
# This script installs or updates SLOzy on CentOS/RHEL systems
#

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/slozy"
SERVICE_USER="slozy"
SERVICE_GROUP="slozy"
SERVICE_NAME="slozy"
BACKUP_DIR="/opt/slozy-backup-$(date +%Y%m%d-%H%M%S)"

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if running on CentOS/RHEL
check_os() {
    if [[ ! -f /etc/redhat-release ]]; then
        print_error "This script is designed for CentOS/RHEL systems"
        exit 1
    fi
    print_status "Detected $(cat /etc/redhat-release)"
}

# Function to check architecture
detect_arch() {
    case $(uname -m) in
        x86_64)
            echo "amd64"
            ;;
        aarch64|arm64)
            echo "arm64"
            ;;
        *)
            print_error "Unsupported architecture: $(uname -m)"
            exit 1
            ;;
    esac
}

# Function to install dependencies
install_dependencies() {
    print_status "Installing dependencies..."
    yum update -y
    yum install -y curl wget unzip
}

# Function to create service user
create_service_user() {
    print_status "Creating service user..."
    if ! getent group "$SERVICE_GROUP" >/dev/null; then
        groupadd -r "$SERVICE_GROUP"
    fi

    if ! getent passwd "$SERVICE_USER" >/dev/null; then
        useradd -r -s /bin/false -g "$SERVICE_GROUP" -d "$INSTALL_DIR" "$SERVICE_USER"
    fi
}

# Function to backup existing installation
backup_existing() {
    if [[ -d "$INSTALL_DIR" ]]; then
        print_warning "Existing installation found. Backing up to $BACKUP_DIR"
        mkdir -p "$BACKUP_DIR"
        cp -r "$INSTALL_DIR"/* "$BACKUP_DIR/" 2>/dev/null || true
    fi
}

# Function to install files
install_files() {
    local arch=$(detect_arch)
    local binary_name="slozy-server-linux-${arch}"

    print_status "Installing SLOzy to $INSTALL_DIR..."

    # Create directories
    mkdir -p "$INSTALL_DIR"/{bin,data,templates,static,logs,config}

    # Install binary
    cp "../$binary_name" "$INSTALL_DIR/bin/slozy-server"
    chmod +x "$INSTALL_DIR/bin/slozy-server"

    # Install assets
    cp -r ../static/* "$INSTALL_DIR/static/"
    cp -r ../templates/* "$INSTALL_DIR/templates/"

    # Install configs
    cp ../config/.env.example "$INSTALL_DIR/.env"
    cp ../config/slozy.service /etc/systemd/system/

    # Set permissions
    chown -R "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR"
    chmod -R 755 "$INSTALL_DIR"
    chmod 640 "$INSTALL_DIR/.env"
}

# Function to configure service
configure_service() {
    print_status "Configuring systemd service..."

    # Update paths in service file
    sed -i "s|/opt/slozy|$INSTALL_DIR|g" /etc/systemd/system/slozy.service

    # Reload systemd
    systemctl daemon-reload
    systemctl enable slozy
}

# Function to check if port is available
check_port() {
    local port=${1:-8080}
    if ss -tuln | grep -q ":$port "; then
        print_warning "Port $port is already in use"
        read -p "Do you want to use a different port? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            read -p "Enter new port: " new_port
            sed -i "s/PORT=.*/PORT=$new_port/" "$INSTALL_DIR/.env"
            check_port "$new_port"
        fi
    fi
}

# Function to restart service
restart_service() {
    print_status "Restarting SLOzy service..."
    systemctl restart slozy

    # Wait for service to start
    sleep 3

    if systemctl is-active --quiet slozy; then
        print_status "Service started successfully"
    else
        print_error "Failed to start service"
        systemctl status slozy
        exit 1
    fi
}

# Function to verify installation
verify_installation() {
    print_status "Verifying installation..."

    # Check service status
    if systemctl is-active --quiet slozy; then
        print_status "✓ Service is running"
    else
        print_error "✗ Service is not running"
        return 1
    fi

    # Check port
    local port=$(grep "^PORT=" "$INSTALL_DIR/.env" | cut -d'=' -f2)
    if ss -tuln | grep -q ":$port "; then
        print_status "✓ Service is listening on port $port"
    else
        print_error "✗ Service is not listening on expected port"
        return 1
    fi

    # Check binary
    if [[ -x "$INSTALL_DIR/bin/slozy-server" ]]; then
        print_status "✓ Binary is installed and executable"
    else
        print_error "✗ Binary not found or not executable"
        return 1
    fi

    # Test HTTP endpoint
    sleep 2
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:$port/health" | grep -q "200"; then
        print_status "✓ Health check passed"
    else
        print_warning "Health check endpoint not responding (this may be normal on first start)"
    fi
}

# Function to show post-install info
show_post_install() {
    local port=$(grep "^PORT=" "$INSTALL_DIR/.env" | cut -d'=' -f2)

    print_status ""
    print_status "Installation completed successfully!"
    print_status ""
    print_status "Service Management:"
    print_status "  Start:   systemctl start slozy"
    print_status "  Stop:    systemctl stop slozy"
    print_status "  Restart: systemctl restart slozy"
    print_status "  Status:  systemctl status slozy"
    print_status ""
    print_status "Logs:"
    print_status "  journalctl -u slozy -f"
    print_status ""
    print_status "Configuration:"
    print_status "  Edit: $INSTALL_DIR/.env"
    print_status ""
    print_status "Application URL:"
    print_status "  http://localhost:$port"
    print_status ""
    if [[ -n "$BACKUP_DIR" && -d "$BACKUP_DIR" ]]; then
        print_status "Backup location:"
        print_status "  $BACKUP_DIR"
    fi
}

# Main execution
main() {
    print_status "Starting SLOzy installation on CentOS/RHEL..."

    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root (use sudo)"
        exit 1
    fi

    # Change to script directory
    cd "$(dirname "$0")"

    # Execute installation steps
    check_os
    install_dependencies
    create_service_user
    backup_existing
    install_files
    configure_service
    check_port
    restart_service
    verify_installation
    show_post_install

    print_status "All done!"
}

# Run main function
main "$@"
